#ifndef __PROMPT_H
#define __PROMPT_H

void prompt();
void tokenise(char *);
int get_input();
#endif