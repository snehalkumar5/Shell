# OS ASSIGNMENT - 3

## SNEHAL KUMAR
## 2019101003
### Features:
### Piping: [pipe.c]
Once the command is passed, tokenize the command by '|'.  For each piped command, create a pipe. Fork the process so child process writes and parent process reads. Duplicate the given input file descriptor(infd) into stdin and pipe[1] to stdout so it reads from infd and writes to pipe[1]. Exit the child process after executing the command, parent process then closes the read pipe and exits.
### Redirection: [redirect.c]
Tokenize the command and get the input and output file names. If '>' then overwrite the file, if '>>' then append the file. Set the open file descriptors to stdin and stdout using dup2() and execute the commands. Once the process is finished, reset the original file descriptors of stdin and stdout. The redirection commands can be treated as arguments of command to be executed when piped.
### User-defined commands:
#### setenv: [env.c]
A new variable is set to environment if it doesnt exist. Else the variable's value is changed using built in command: setenv(variable,value,overwrite).
### unsetenv: [env.c]
Any existing environment variable specified is deleted from environment, else it does nothing.
### jobs: [jobs.c]
Go through all existing background jobs, check their status in /proc/pid/status and is printed.
### kjobs: [jobs.c]
The specified job number is found and sent the signal passed in argument using kill(job,signal).
### fg: [procs.c]
For the specified background process, find it and transfer control of terminal to the process and set the process group id of process so it can run in foreground and receive the signals, send a SIGCONT signal to change state to running and transfer the control of terminal back after execution with appropriate error handling.
### bg: [procs.c]
The specified process, if currently stopped, is changed to running by sending SIGCONT signal with appropriate error handling.
### overkill: [shell.c]
Go through all the background processes and kill them using kill(jobPID,SIGKILL) corresponding to kill process.
### quit: [shell.c]
Exits the shell using exit().
### SIGNAL HANDLING
### CTRL+Z:
While the foreground processes are running (in fg/normal), a waitpid signal is checked for SIGSTSP (when CTRL+Z is pressed) and process is stopped and sent to background processes.
### CTRL+C:
While initialising, set the default handler of ctrl+c as SIG_IGN(ignore when in shell). Once the processes start, set it back to SIG_DFL(default when child processes are invoked).
### BONUS
### Last working directory [cd.c]
An additional condition is added for when argument passed is '-'. A global variable stores the last working directory and chdir to that directory after printing the directory and updates the variable.
### Exit codes
Each function call returns 0 if successfully executed else -1. The global variable errno checks for successful execution and -1 is returned if the errno is set by any process in a function. Corresponding to the return values, :') is printed if 0 else :'( is printed before the prompt.
### Chaining with logical AND and OR: [logical.c]
The command is first tokenized by '@\$'. The commands are then executed on the basis of the exit status of the previous command and the logical operator. If '@' and previous exit status=0(success), the next command is executed.
If '\$' and previous exit status=-1(fail), the next command is executed.
Finally the function returns the overall truth value after executing all the commands/short circuited.
